# Write your tests here. Use only the Django testing framework.
from django.test import TestCase

