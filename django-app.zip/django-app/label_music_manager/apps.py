# You should not edit this file
from django.apps import AppConfig


class LabelMusicManagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'label_music_manager'
